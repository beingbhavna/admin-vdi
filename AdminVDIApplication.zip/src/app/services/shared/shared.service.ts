import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { GlobalRestService } from 'src/app/services/rest/global-rest.service';
import { MessageService } from 'ngx-i2k2-message-lib';
import { AuthService } from '../../services/auth/auth.service';
import { HandelError } from 'src/app/shared/enumrations/app-enum.enumerations';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  public serverName: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  public selectedAction: BehaviorSubject<any> = new BehaviorSubject<any>('');
  public vdiData: BehaviorSubject<any> = new BehaviorSubject<any>('');
  //public examPreviewParams: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  public serverId: BehaviorSubject<any> = new BehaviorSubject<any>('');

  constructor(
    private router: Router,
    private restService: GlobalRestService,
    private messageService: MessageService,
    private authService: AuthService
  ) {}

  setLoaderVisibility(showLoader: boolean) {
    const spinner = document.getElementsByClassName('spinner')[0];
    if (showLoader) {
      if (spinner.classList.contains('hidden')) {
        spinner.classList.remove('hidden');
        spinner.classList.add('visible');
      }
    } else {
      if (spinner.classList.contains('visible')) {
        spinner.classList.remove('visible');
        spinner.classList.add('hidden');
      }
    }
  }

  errorAlert(errorResponse) {
    //showing message when user is not logged in
    if (
      errorResponse.httpErrorResponse.data[0].attributes.message[0] ==
      'Invalid Token'
    ) {
      //showing message when user is token is expired
      const successMessage = {
        http_status: '200',
        data: [
          {
            type: 'VALID_RETURN',
            attributes: {
              message_type: '',
              message: ['Session Timeout, Please Login Again.'],
            },
            data: null,
          },
        ],
      };
      this.messageService
        .okRedirectModal(successMessage, 'ERROR', 'OK')
        .subscribe((result) => {
          this.authService.logout();
          this.router.navigate(['/login']);
          this.messageService.hideModal();
        });
    } else {
      this.messageService
        .okRedirectModal(errorResponse.httpErrorResponse, 'ERROR', 'OK')
        .subscribe((result) => {
          this.messageService.hideModal();
        });
    }
  }
}
