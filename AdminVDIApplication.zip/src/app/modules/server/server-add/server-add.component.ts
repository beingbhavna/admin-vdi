import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'ngx-i2k2-message-lib';
import { AppsettingsConfService } from 'src/app/services/conf/appsettings-conf/appsettings-conf.service';
import { GlobalRestService } from 'src/app/services/rest/global-rest.service';
import { HandelError } from 'src/app/shared/models/app.models';
import { PrimaryHeaderService } from '../../layout/primary-header/primary-header.service';
import { Server } from '../../../shared/enumrations/app-enum.enumerations';

@Component({
  selector: 'app-server-add',
  templateUrl: './server-add.component.html',
  styleUrls: ['./server-add.component.scss'],
})
export class ServerAddComponent implements OnInit {
  public addServerFormGroup: FormGroup;

  private appRoutes: any = {};
  public serverId: any;

  constructor(
    private restService: GlobalRestService,
    private configService: AppsettingsConfService,
    private primaryHeader: PrimaryHeaderService
  ) {
    this.restService.ShowLoadingSpinner = true;
    this.restService.AlertAndErrorAction = HandelError.ShowAndReturn;
    this.configService.getAppRoutes.subscribe(
      (configData) => {
        this.appRoutes = configData;
      },
      (error) => {
        console.error('Error for configService.getAppRoutes: ', error);
      }
    );
  }

  ngOnInit() {
    //setting page title
    this.getServerList();
    this.primaryHeader.pageTitle.next('Server Add');

    this.addServerFormGroup = new FormGroup({
      user_name: new FormControl('', Validators.required),
      connection_name: new FormControl('', Validators.required),
      ostype_name: new FormControl('', Validators.required),
      user_password: new FormControl(''),
      confirmedPassword: new FormControl(''),
      server_type_id: new FormControl(''),
    });
  }

  getServerList() {
    this.restService.ApiEndPointUrlOrKey = Server.getServerList;
    this.restService.callApi().subscribe(
      (successResponse) => {},
      (errorResponse) => {}
    );
  }

  onformSubmit() {
    if (this.addServerFormGroup.valid === false) {
      let form = document.getElementById('addServerForm');
      form.classList.add('was-validated');
    } else if (this.addServerFormGroup.valid === true) {
      //  call API for server add and redirect to server list page
      // this.restService.ApiEndPointUrlOrKey = Server.addServerList;
      // this.restService.HttpPostParams = this.addServerFormGroup.value;
      // this.restService.callApi().subscribe(
      //   (successResponse) => {},
      //   (errorResponse) => {
      //     // console.error('ERROR: ', errorResponse.message[0]);
      //   }
      // );
    }
  }

  reset() {
    this.addServerFormGroup.reset({
      user_name: '',
      server_type_id: '',
      connection_name: '',
      ostype_name: '',
      user_password: '',
      confirmedPassword: '',
    });
  }
}
