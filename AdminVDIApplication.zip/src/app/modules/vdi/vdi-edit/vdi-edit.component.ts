import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MessageService } from 'ngx-i2k2-message-lib';
import { AppsettingsConfService } from 'src/app/services/conf/appsettings-conf/appsettings-conf.service';
import { GlobalRestService } from 'src/app/services/rest/global-rest.service';
import { SharedService } from 'src/app/services/shared/shared.service';
import {
  HandelError,
  Vdi,
} from 'src/app/shared/enumrations/app-enum.enumerations';
import { PrimaryHeaderService } from '../../layout/primary-header/primary-header.service';

@Component({
  selector: 'app-vdi-edit',
  templateUrl: './vdi-edit.component.html',
  styleUrls: ['./vdi-edit.component.scss'],
})
export class VdiEditComponent implements OnInit {
  public editVdiFormGroup: FormGroup;
  public vdiId: any;
  public serverId: any;
  public vdiData: any;
  public userId: any;
  private appRoutes: any = {};

  constructor(
    private route: ActivatedRoute,
    private restService: GlobalRestService,
    private configService: AppsettingsConfService,
    private messageService: MessageService,
    private router: Router,
    private primaryHeader: PrimaryHeaderService,
    public sharedService: SharedService
  ) {
    this.restService.ShowLoadingSpinner = true;
    this.restService.AlertAndErrorAction = HandelError.ShowAndReturn;
    this.configService.getAppRoutes.subscribe(
      (configData) => {
        this.appRoutes = configData;
      },
      (error) => {
        console.error('Error for configService.getAppRoutes: ', error);
      }
    );
  }

  ngOnInit() {
    this.primaryHeader.pageTitle.next('VDI Edit');
    this.initializeFields();
    this.route.params.subscribe((params: Params) => {
      this.vdiId = params['vdiId'];
      this.serverId = params['serverId'];
      this.getData();
    });
  }

  initializeFields() {
    this.editVdiFormGroup = new FormGroup({
      name: new FormControl({ value: '', disabled: true }),
      connection_name: new FormControl({ value: '', disabled: true }),
      connection_id: new FormControl(''),
      user_id: new FormControl({ value: '', disabled: true }),
      server_name: new FormControl({ value: '', disabled: true }),
      server_id: new FormControl({ value: '', disabled: true }),
      hostname: new FormControl({ value: '', disabled: true }),
      image_os_type: new FormControl({ value: '', disabled: true }),

      create_drive_path: new FormControl('', Validators.required),
      disable_audio: new FormControl('', Validators.required),
      enable_drive: new FormControl('', Validators.required),
      enable_font_smoothing: new FormControl('', Validators.required),
      enable_printing: new FormControl('', Validators.required),
      ignore_cert: new FormControl('', Validators.required),
      drive_name: new FormControl('', Validators.required),
      drive_path: new FormControl('', Validators.required),
      port: new FormControl('', Validators.required),
      printer_name: new FormControl('', Validators.required),
      security: new FormControl('', Validators.required),
    });
  }

  getData() {
    var keyData = [
      {
        name: 'connectionId',
        value: this.vdiId,
      },
      {
        name: 'serverId',
        value: this.serverId,
      },
    ];
    this.restService.ApiEndPointUrlOrKey = Vdi.getVdiListById;
    this.restService.AlertAndErrorAction = HandelError.ShowAndReturn;
    this.restService.ShowLoadingSpinner = true;
    this.restService.callApi(keyData).subscribe(
      (sucessResponse) => {
        if (sucessResponse != null) {
          this.editVdiFormGroup.patchValue({
            connection_name: sucessResponse.vdi[0].connection_name,
            connection_id: sucessResponse.vdi[0].connection_id,
            user_id: sucessResponse.vdi[0].user_id,
            name: sucessResponse.vdi[0].name,
            server_name: sucessResponse.vdi[0].server_name,
            server_id: sucessResponse.vdi[0].server_id,
            hostname: sucessResponse.vdi[0].hostname,
            image_os_type: sucessResponse.vdi[0].image_os_type,
          });
          sucessResponse.vdi[1].vdifeatures.forEach((element) => {
            if (element.parameter_name == 'create-drive-path') {
              this.editVdiFormGroup.patchValue({
                create_drive_path: element.parameter_value,
              });
            } else if (element.parameter_name == 'disable-audio') {
              this.editVdiFormGroup.patchValue({
                disable_audio: element.parameter_value,
              });
            } else if (element.parameter_name == 'enable-drive') {
              this.editVdiFormGroup.patchValue({
                enable_drive: element.parameter_value,
              });
            } else if (element.parameter_name == 'enable-font-smoothing') {
              this.editVdiFormGroup.patchValue({
                enable_font_smoothing: element.parameter_value,
              });
            } else if (element.parameter_name == 'enable-printing') {
              this.editVdiFormGroup.patchValue({
                enable_printing: element.parameter_value,
              });
            } else if (element.parameter_name == 'ignore-cert') {
              this.editVdiFormGroup.patchValue({
                ignore_cert: element.parameter_value,
              });
            } else if (element.parameter_name == 'drive-name') {
              this.editVdiFormGroup.patchValue({
                drive_name: element.parameter_value,
              });
            } else if (element.parameter_name == 'drive-path') {
              this.editVdiFormGroup.patchValue({
                drive_path: element.parameter_value,
              });
            } else if (element.parameter_name == 'port') {
              this.editVdiFormGroup.patchValue({
                port: element.parameter_value,
              });
            } else if (element.parameter_name == 'printer-name') {
              this.editVdiFormGroup.patchValue({
                printer_name: element.parameter_value,
              });
            } else if (element.parameter_name == 'security') {
              this.editVdiFormGroup.patchValue({
                security: element.parameter_value,
              });
            }
          });
        }
      },
      (errorResponse) => {
        if (errorResponse !== undefined) {
          this.sharedService.errorAlert(errorResponse);
        }
      }
    );
  }

  private getParams() {
    let params = this.editVdiFormGroup.value;
    params['user_id'] = this.userId;
    return params;
  }

  onformSubmit() {
    debugger;
    if (this.editVdiFormGroup.valid === false) {
      let form = document.getElementById('editVdiForm');
      form.classList.add('was-validated');
    } else if (this.editVdiFormGroup.valid === true) {
      let params = this.getParams();
      // call api code here...
      if (Object.keys(this.appRoutes).length !== 0) {
        var keyData = [
          {
            name: 'connectionId',
            value: this.vdiId,
          },
        ];
        this.restService.ApiEndPointUrlOrKey = Vdi.updateVdi;
        this.restService.HttpPostParams = params;
        this.restService.AlertAndErrorAction = HandelError.ShowAndReturn;
        this.restService.callApi(keyData).subscribe(
          (successResponse) => {
            this.messageService
              .okRedirectModal(successResponse, 'SUCCESS', 'Go to List')
              .subscribe((result) => {
                if (result == true) {
                  // OK = true for redirection
                  this.messageService.hideModal();
                  this.sharedService.serverId.next(this.serverId);
                  this.router.navigate(['vdi']);
                } else {
                  // NO/CANCEL = false
                  this.messageService.hideModal();
                }
              });
          },
          (errorResponse) => {}
        );
      }
    }
  }

  public checkInput(event) {
    var ctrlCode = event.ctrlKey ? event.ctrlKey : event.metaKey; // get key cross-browser
    var charCode = event.which ? event.which : event.keyCode; // get key cross-browser
    if (
      // Allow: home, end, left, right, down, up
      (charCode >= 35 && charCode <= 40) ||
      // Allow: Ctrl+A,Ctrl+C,Ctrl+V, Command+A
      ((charCode == 65 || charCode == 86 || charCode == 67) &&
        ctrlCode === true)
    ) {
      return true;
    }
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    } else {
      return true;
    }
  }

  back() {
    this.router.navigateByUrl('vdi');
  }

  ngOnDestroy() {}
}
