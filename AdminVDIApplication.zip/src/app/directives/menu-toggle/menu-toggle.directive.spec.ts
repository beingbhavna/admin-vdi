import { MenuToggleDirective } from './menu-toggle.directive';


describe('MenuToggleDirective', () => {
  it('should create an instance', () => {
    const directive = new MenuToggleDirective();
    expect(directive).toBeTruthy();
  });
});
