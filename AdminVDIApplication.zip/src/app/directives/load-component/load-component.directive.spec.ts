// import { LoadComponentDirective } from './load-component.directive';

// describe('LoadComponentDirective', () => {
//   it('should create an instance', () => {
//     const directive = new LoadComponentDirective();
//     expect(directive).toBeTruthy();
//   });
// });
