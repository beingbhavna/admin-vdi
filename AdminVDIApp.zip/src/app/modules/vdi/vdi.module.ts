import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VdiRoutingModule } from './vdi-routing.module';



@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    VdiRoutingModule
  ]
})
export class VdiModule { }
