import { FilterToggleDirective } from './filter-toggle.directive';


describe('FilterToggleDirective', () => {
  it('should create an instance', () => {
    const directive = new FilterToggleDirective();
    expect(directive).toBeTruthy();
  });
});
