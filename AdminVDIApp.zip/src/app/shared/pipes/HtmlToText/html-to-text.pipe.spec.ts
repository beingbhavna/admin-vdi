import { HtmlToTextPipe } from './html-to-text.pipe';

describe('HtmlToTextPipe', () => {
  it('create an instance', () => {
    const pipe = new HtmlToTextPipe();
    expect(pipe).toBeTruthy();
  });
});
